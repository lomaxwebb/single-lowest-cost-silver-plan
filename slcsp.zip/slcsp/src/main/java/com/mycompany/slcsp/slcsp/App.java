package com.mycompany.slcsp.slcsp;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

/**
 * SLCSP
 * Populates slcsp.csv with data representing the "second lowest cost silver plan" for each given zip code.
 */
public class App 
{
	
	final static String SLCSP_FILENAME = "slcsp.csv",
		ZIPCODES_FILENAME = "zips.csv",
		PLANS_FILENAME = "plans.csv";
	
    public static void main( String[] args ) throws IOException
    {
    	
    	//Set up file reader and an object to store its contents, which we will mutate.
    	CSVReader outputFileReader = new CSVReader(
    		new FileReader(SLCSP_FILENAME)
    	);
    	List<String[]> outputFileBody = outputFileReader.readAll();

    	//Iterate through each zip code within slcsp.csv, calculating its second lowest cost silver plan based upon data in zips.csv and plans.csv.
    	int index = 1;		//Track which row we're on. We'll start on the second index so as to skip the headers.
    	for(String[] outputFileRow : outputFileBody) {
    		
    		index++;
		
    		//Determine which zip code we're currently working with.
    		String zipCode = outputFileRow[0];
		
    		//Read data from zips.csv, determining applicable state and rate area along the way.
    		CSVReader inputFileReader = new CSVReader(
    	    	new FileReader(ZIPCODES_FILENAME)
    	    );
    		List<String[]> inputFileBody = inputFileReader.readAll();
    		inputFileBody.remove(0);	//Remove headers.
    		String state = null,
    			rateArea = null;
    		boolean zipCodeIsAmbiguous = false;
    		for (String[] inputFileRow : inputFileBody) {
    			String zipCodeCurrentItem = inputFileRow[0],
    				stateCurrentItem = inputFileRow[1],
    				rateAreaCurrentItem = inputFileRow[4];
    			if (zipCodeCurrentItem.equals(zipCode)) {
    				if (state == null) {
    					state = stateCurrentItem;
    				}
    				if (!state.equals(stateCurrentItem)) {	//If we discover multiple states for the same zip code
    					zipCodeIsAmbiguous = true;			//then the zip code is ambiguous.
    				}
    				if (rateArea == null) {
    					rateArea = rateAreaCurrentItem;
    				}
    				if (!rateArea.equals(rateAreaCurrentItem)) {	//If we discover multiple rate areas for the same
    					zipCodeIsAmbiguous = true;					// zip code then the zip code is ambiguous.
    				}
    			}
    		}
    		
    		//Read data from plans.csv, determining value of second lowest cost silver plan along the way.
    		if (!zipCodeIsAmbiguous) {
    			inputFileReader = new CSVReader(
    	    	    new FileReader(PLANS_FILENAME)
    	    	);
    			inputFileBody.remove(0);	//Remove headers.
    			inputFileBody = inputFileReader.readAll();
    			double secondLowestCostSilverPlan = Double.MAX_VALUE,
    					lowestCostSilverPlan = Double.MAX_VALUE;	//Tracking the lowest value will be useful in tracking the second lowest value.
    			for (String[] inputFileRow : inputFileBody) {
    				String stateCurrentItem = inputFileRow[1],
    					metalLevelCurrentItem = inputFileRow[2],
    					rateCurrentItem = inputFileRow[3],
    					rateAreaCurrentItem = inputFileRow[4];
    				if (rateAreaCurrentItem.equals(rateArea) && stateCurrentItem.equals(state) && metalLevelCurrentItem.equals("Silver")) {
    					Double rateCurrentItemAsDouble = Double.parseDouble(rateCurrentItem);
    					if (lowestCostSilverPlan == Double.MAX_VALUE) {				//If lowest cost variable is still at its initial value,
    						lowestCostSilverPlan = rateCurrentItemAsDouble;			//set it equal to the current rate.
    					}
    					if (secondLowestCostSilverPlan == Double.MAX_VALUE) {		//If second lowest cost variable is still at its initial value,
    						secondLowestCostSilverPlan = rateCurrentItemAsDouble;	//set it equal to the current rate.
    					}
    					if ((secondLowestCostSilverPlan == lowestCostSilverPlan && rateCurrentItemAsDouble > lowestCostSilverPlan)				//If a value is discovered which is nearest to the lowest cost without being less
    						|| (rateCurrentItemAsDouble < secondLowestCostSilverPlan) && (rateCurrentItemAsDouble > lowestCostSilverPlan)) {	//than or equal to it, update the second lowest cost value.
    						secondLowestCostSilverPlan = rateCurrentItemAsDouble;
    					}
    					if (rateCurrentItemAsDouble < lowestCostSilverPlan) {		//If a value is discovered which is less than the lowest cost,
    						secondLowestCostSilverPlan = lowestCostSilverPlan;		//update lowest cost and second lowest cost.
    						lowestCostSilverPlan = rateCurrentItemAsDouble;
    					}
    				}
    			}
    			if (secondLowestCostSilverPlan != Double.MAX_VALUE) {
    				outputFileBody.get(index-2)[1] = "" + secondLowestCostSilverPlan;
    			}
    		}
    		
    		//Write output to file.
    		CSVWriter writer = new CSVWriter(
    	    	new FileWriter(SLCSP_FILENAME)
    	    );
    	    writer.writeAll(outputFileBody);
    	    
    	    //Close readers and writers.
    	    inputFileReader.close();
    	    outputFileReader.close();
    	    writer.flush();
    	    writer.close();

    	}
	
    }
    
}
